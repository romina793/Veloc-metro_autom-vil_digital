import UIKit

enum Velocidades: Int {
    
    case Apagado = 0, VelocidadBaja = 20, VelocidadMedia = 50, VelocidadAlta = 120
    
    init(velocidadInicial : Velocidades){
        self = .Apagado
    }
    
}

class Auto {
    
    var velocidad : Velocidades
    
    init(velocidadIncial: Velocidades) {
        self.velocidad = Velocidades(velocidadInicial: .Apagado)
    }
    
    func cambioDeVelocidad() -> (actual : Int, velocidadEnCadena: String) {
       let velocidadActual = velocidad
    
    switch velocidad {
    case .Apagado:
        velocidad = Velocidades.VelocidadBaja
    case .VelocidadBaja:
        velocidad = Velocidades.VelocidadMedia
    case .VelocidadMedia:
        velocidad = Velocidades.VelocidadAlta
    case .VelocidadAlta:
        velocidad = Velocidades.VelocidadMedia
    }
    
    return (velocidadActual.rawValue, "\(velocidadActual)")
    
    }

}

var miAuto = Auto(velocidadIncial: Velocidades.Apagado)

for _ in 0...19 {
    let velocidad = miAuto.cambioDeVelocidad()
        print("\(velocidad.0), \(velocidad.1)")
}
